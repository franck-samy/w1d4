const cars = [
  { brand: "Mercedes", price: 15000, year: 2015 },
  { brand: "Seat", price: 5000, year: 2000 },
  { brand: "Opel", price: 20000, year: 2016 },
  { brand: "Toyota", price: 13000, year: 2012 },
  { brand: "BMW", price: 17000, year: 2020 },
  { brand: "Renault", price: 11000, year: 2010 },
  { brand: "Peugeot", price: 9000, year: 2007 },
];
